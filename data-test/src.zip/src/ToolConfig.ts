export default class ToolConfig {
  static draggable: boolean = true
}
