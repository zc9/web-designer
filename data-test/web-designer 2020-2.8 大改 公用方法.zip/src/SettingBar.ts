export default class SettingBar {
  $el: JQuery
  constructor() {
    let $el = $('.setting-bar')
    let $pageConfig = $el.find('.page-config')
    let $assistConfig = $el.find('.assist-config')
    let $magnetConfig = $el.find('.magnet-config')

  }
}
