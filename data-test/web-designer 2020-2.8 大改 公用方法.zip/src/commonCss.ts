export function isEmpty(v) {
    switch (typeof v) {
    case 'undefined':
        return true;
    case 'string':
        if (v.replace(/(^[ \t\n\r]*)|([ \t\n\r]*$)/g, '').length == 0) return true;
        break;
    case 'boolean':
        if (!v) return true;
        break;
    case 'number':
        if (0 === v || isNaN(v)) return true;
        break;
    case 'object':
        if (null === v || v.length === 0) return true;
        for (var i in v) {
            return false;
        }
        return true;
    }
    return false;
}

/*旺旺链接*/
export function wwUrl(url,mode,whao,stype){
  return mode =="wwlink" ? '//amos.alicdn.com/msg.aw?&v=2&uid='+whao+'&site=enaliint&s='+stype+'&charset=UTF-8' : url
}

/*链接 与旺旺链接 切换信息*/
export function onLinkModeChanged($layerElem, linkMode) {
  let $wangBox = $layerElem.find('.wang-box')
  let $linkBox = $layerElem.find('.link-box')
  if (linkMode === 'urlink') {
    $wangBox.hide()
    $linkBox.show()
  } else if (linkMode === 'wwlink') {
    $linkBox.hide()
    $wangBox.show()
  }
}
/*阴影外框 生成样式 */
export function boxShadow(sdX,sdY,sdBlur,sdSize,sdColor) {
  let bShadow=sdX+'px'
  bShadow+=' '+sdY+'px'
  bShadow+=sdBlur ? ' '+sdBlur+'px': ''
  bShadow+=sdSize ? ' '+sdSize+'px': ''
  bShadow+=sdColor ? ' '+sdColor: ''
  return bShadow
}